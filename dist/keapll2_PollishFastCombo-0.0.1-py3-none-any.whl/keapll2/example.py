def germany(self):
    print("Germany!")
